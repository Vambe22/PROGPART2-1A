﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp;
using System.Collections.Generic;

namespace RecipeAppTests
{
	[TestClass]
	public class RecipeTests
	{
		[TestMethod]
		public void TestTotalCalories()
		{
			// Arrange
			var recipe = new Recipe("Test Recipe");

			// Using reflection to access private method for testing purposes
			typeof(Recipe).GetMethod("EnterRecipeDetails", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
				.Invoke(recipe, new object[]
				{
					new List<Ingredient>
					{
						new Ingredient { Name = "Sugar", Quantity = 2, Unit = "tbsp", Calories = 100, FoodGroup = "Carbs" },
						new Ingredient { Name = "Butter", Quantity = 1, Unit = "tbsp", Calories = 102, FoodGroup = "Fats" }
					},
					new List<Step>
					{
						new Step { Description = "Mix ingredients." }
					}
				});

			// Act
			int totalCalories = recipe.TotalCalories();

			// Assert
			Assert.AreEqual(202, totalCalories);
		}
	}
}
