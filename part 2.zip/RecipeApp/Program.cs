﻿using RecipeApp;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp {
	class Program
	{
		static void Main(string[] args)
		{
			List<Recipe> recipes = new List<Recipe>(); // List to store multiple recipes

			bool exit = false;
			while (!exit)
			{
				Console.WriteLine("\nMenu:");
				Console.WriteLine("1. Enter Recipe Details");
				Console.WriteLine("2. Display Recipe");
				Console.WriteLine("3. Scale Recipe");
				Console.WriteLine("4. Reset Quantities");
				Console.WriteLine("5. Clear Recipe");
				Console.WriteLine("6. List All Recipes");
				Console.WriteLine("7. Exit");
				Console.Write("Enter your choice: ");
				int choice = int.Parse(Console.ReadLine());

				switch (choice)
				{
					case 1:
						// Enter new recipe details
						Console.Write("Enter the recipe name: ");
						string name = Console.ReadLine();
						var recipe = new Recipe(name);
						recipe.CaloriesExceeded += message => Console.WriteLine(message);
						recipe.EnterRecipeDetails();
						recipes.Add(recipe);
						break;
					case 2:
						// Display a specific recipe
						DisplayRecipeList(recipes);
						Console.Write("Enter the recipe name to display: ");
						string recipeName = Console.ReadLine();
						var selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
						if (selectedRecipe != null)
						{
							selectedRecipe.DisplayRecipe();
						}
						else
						{
							Console.WriteLine("Recipe not found.");
						}
						break;
					case 3:
						// Scale a specific recipe
						DisplayRecipeList(recipes);
						Console.Write("Enter the recipe name to scale: ");
						recipeName = Console.ReadLine();
						selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
						if (selectedRecipe != null)
						{
							Console.Write("Enter scale factor (0.5, 2, or 3): ");
							double factor = double.Parse(Console.ReadLine());
							selectedRecipe.ScaleRecipe(factor);
						}
						else
						{
							Console.WriteLine("Recipe not found.");
						}
						break;
					case 4:
						// Reset quantities of a specific recipe
						DisplayRecipeList(recipes);
						Console.Write("Enter the recipe name to reset quantities: ");
						recipeName = Console.ReadLine();
						selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
						if (selectedRecipe != null)
						{
							selectedRecipe.ResetQuantities();
						}
						else
						{
							Console.WriteLine("Recipe not found.");
						}
						break;
					case 5:
						// Clear details of a specific recipe
						DisplayRecipeList(recipes);
						Console.Write("Enter the recipe name to clear: ");
						recipeName = Console.ReadLine();
						selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
						if (selectedRecipe != null)
						{
							selectedRecipe.ClearRecipe();
						}
						else
						{
							Console.WriteLine("Recipe not found.");
						}
						break;
					case 6:
						// List all recipes
						DisplayRecipeList(recipes);
						break;
					case 7:
						// Exit the application
						exit = true;
						break;
					default:
						Console.WriteLine("Invalid choice. Please enter a number from 1 to 7.");
						break;
				}
			}
		}

		// Method to display a list of all recipes in alphabetical order
		static void DisplayRecipeList(List<Recipe> recipes)
		{
			Console.WriteLine("\nRecipes:");
			foreach (var recipe in recipes.OrderBy(r => r.Name))
			{
				Console.WriteLine(recipe.Name);
			}
		}
	}
}