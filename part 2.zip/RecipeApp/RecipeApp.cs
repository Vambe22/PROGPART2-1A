﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp
{
	// Class representing an Ingredient with properties for name, quantity, unit, calories, and food group
	public class Ingredient
	{
		public string Name { get; set; }
		public double Quantity { get; set; }
		public string Unit { get; set; }
		public int Calories { get; set; }
		public string FoodGroup { get; set; }
	}

	// Class representing a Step with a description of the step
	public class Step
	{
		public string Description { get; set; }
	}

	// Delegate to notify when calories exceed a certain limit
	public delegate void CaloriesExceededHandler(string message);

	// Class representing a Recipe with a name, list of ingredients, and list of steps
	public class Recipe
	{
		public string Name { get; set; }
		private List<Ingredient> ingredients;
		private List<Step> steps;
		private List<Ingredient> originalIngredients; // To keep track of original quantities

		// Event using the CaloriesExceededHandler delegate
		public event CaloriesExceededHandler CaloriesExceeded;

		// Constructor to initialize a new Recipe with a name
		public Recipe(string name)
		{
			Name = name;
			ingredients = new List<Ingredient>();
			steps = new List<Step>();
		}

		// Method to enter recipe details including ingredients and steps
		private void EnterRecipeDetails(List<Ingredient> inputIngredients, List<Step> inputSteps)
		{
			ingredients = inputIngredients;
			steps = inputSteps;

			// Save original ingredients for resetting quantities
			originalIngredients = ingredients.Select(ingredient => new Ingredient
			{
				Name = ingredient.Name,
				Quantity = ingredient.Quantity,
				Unit = ingredient.Unit,
				Calories = ingredient.Calories,
				FoodGroup = ingredient.FoodGroup
			}).ToList();
		}

		// Method to display the recipe including ingredients, steps, and total calories
		public void DisplayRecipe()
		{
			Console.WriteLine($"\nRecipe: {Name}");
			Console.WriteLine("Ingredients:");
			foreach (var ingredient in ingredients)
			{
				Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})");
			}

			Console.WriteLine("\nSteps:");
			foreach (var step in steps)
			{
				Console.WriteLine(step.Description);
			}

			int totalCalories = ingredients.Sum(ingredient => ingredient.Calories);
			Console.WriteLine($"\nTotal Calories: {totalCalories}");
			if (totalCalories > 300)
			{
				CaloriesExceeded?.Invoke($"Warning: This recipe exceeds 300 calories with a total of {totalCalories} calories.");
			}
		}

		// Method to scale the recipe by a given factor
		public void ScaleRecipe(double factor)
		{
			foreach (var ingredient in ingredients)
			{
				ingredient.Quantity *= factor;
			}
		}

		// Method to reset the ingredient quantities to their original values
		public void ResetQuantities()
		{
			ingredients = originalIngredients.Select(ingredient => new Ingredient
			{
				Name = ingredient.Name,
				Quantity = ingredient.Quantity,
				Unit = ingredient.Unit,
				Calories = ingredient.Calories,
				FoodGroup = ingredient.FoodGroup
			}).ToList();
		}

		// Method to clear the recipe details
		public void ClearRecipe()
		{
			ingredients.Clear();
			steps.Clear();
		}

		// Method to get total calories
		public int TotalCalories()
		{
			return ingredients.Sum(ingredient => ingredient.Calories);
		}

		internal void EnterRecipeDetails()
		{
			throw new NotImplementedException();
		}
	}
}
